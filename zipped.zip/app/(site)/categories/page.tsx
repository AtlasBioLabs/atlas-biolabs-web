import type { Metadata } from "next";
import Link from "next/link";

import { Breadcrumbs } from "@/components/site/breadcrumbs";
import { JsonLd } from "@/components/site/json-ld";
import { ResourceLinksPanel } from "@/components/site/resource-links-panel";
import { getAllBlogPosts } from "@/lib/blog";
import {
  createPageMetadata,
  categoryCanonical,
  getBreadcrumbSchema,
  getStaticBreadcrumbItems,
} from "@/lib/seo";
import { collectionPageJsonLd, itemListJsonLd } from "@/lib/schema";
import { catalogProductSlugsByCategory, productCategories } from "@/lib/site-content";

export const metadata: Metadata = createPageMetadata({
  title: "Categories",
  path: "/categories",
  description:
    "Browse Atlas BioLabs peptide categories with commercial sourcing context, MOQ visibility, and quote-ready support for U.S. and international buyers.",
  keywords: [
    "peptide categories",
    "signal peptides",
    "carrier peptides",
    "metabolic peptides",
    "growth peptides",
  ],
});

export default function CategoryIndexPage() {
  const categoryGuides = getAllBlogPosts()
    .filter((post) =>
      ["types-of-peptides", "peptide-supplier-guide", "how-to-buy-peptides"].includes(
        post.slug
      )
    )
    .map((post) => ({
      title: post.title,
      href: `/blog/${post.slug}`,
      description: post.description,
      eyebrow: "Buyer Guide",
    }));

  const breadcrumbItems = getStaticBreadcrumbItems("categories");
  const breadcrumbSchema = getBreadcrumbSchema(breadcrumbItems);
  const collectionSchema = collectionPageJsonLd({
    name: "Peptide Categories",
    description:
      "Atlas BioLabs peptide category hub for product discovery, commercial sourcing context, and documentation-backed B2B quote planning.",
    url: categoryCanonical("").replace(/\/$/, ""),
  });
  const categoryItemListSchema = itemListJsonLd(
    productCategories.map((category, index) => ({
      name: category.label,
      url: categoryCanonical(category.id),
      position: index + 1,
    }))
  );

  return (
    <>
      <JsonLd id="categories-breadcrumb-schema" data={breadcrumbSchema} />
      <JsonLd id="categories-collection-schema" data={collectionSchema} />
      <JsonLd id="categories-item-list-schema" data={categoryItemListSchema} />

      <section className="section-space border-b border-border/70 bg-gradient-to-b from-[#f8fbff] to-white">
        <div className="site-container">
          <Breadcrumbs items={breadcrumbItems} />
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[var(--brand-blue)]">
            Categories
          </p>
          <h1 className="mt-3 max-w-4xl text-4xl font-semibold text-[var(--brand-navy)]">
            Shop Peptides by Category
          </h1>
          <p className="mt-4 max-w-3xl text-base leading-relaxed text-muted-foreground">
            Compare peptide groups, review commercial sourcing context, and move
            directly into product listings with documentation support, batch
            transparency language, and quote-ready next steps.
          </p>
        </div>
      </section>

      <section className="section-space pt-10">
        <div className="site-container grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {productCategories.map((category) => {
            const productCount = catalogProductSlugsByCategory[category.id]?.length ?? 0;

            return (
              <article key={category.id} className="surface-card p-6">
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[var(--brand-blue)]">
                  {productCount} Product{productCount === 1 ? "" : "s"}
                </p>
                <h2 className="mt-2 text-xl font-semibold text-[var(--brand-navy)]">
                  {category.label}
                </h2>
                <p className="mt-2 text-sm text-muted-foreground">{category.description}</p>
                <Link
                  href={`/categories/${category.id}`}
                  className="mt-5 inline-flex text-sm font-medium text-[var(--brand-blue)] hover:underline"
                >
                  View {category.label}
                </Link>
              </article>
            );
          })}
        </div>
      </section>

      <ResourceLinksPanel
        eyebrow="Category Guides"
        title="Use These Articles to Compare Peptide Categories More Effectively"
        description="These blog posts explain how peptide categories differ, how buyers source them, and how to move from category selection into product evaluation."
        links={categoryGuides}
      />
    </>
  );
}
