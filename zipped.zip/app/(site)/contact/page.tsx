import type { Metadata } from "next";

import { Breadcrumbs } from "@/components/site/breadcrumbs";
import { ContactForm } from "@/components/site/contact-form";
import { CtaSection } from "@/components/site/cta-section";
import { JsonLd } from "@/components/site/json-ld";
import { ResourceLinksPanel } from "@/components/site/resource-links-panel";
import { COMPANY_INFO } from "@/lib/company";
import {
  createPageMetadata,
  getBreadcrumbSchema,
  getStaticBreadcrumbItems,
} from "@/lib/seo";
import { contactCta, contactDetails } from "@/lib/site-content";

export const metadata: Metadata = createPageMetadata({
  title: "Contact Atlas BioLabs | Peptide Sourcing & Documentation Support",
  path: "/contact",
  description:
    "Contact Atlas BioLabs for commercial peptide sourcing, MOQ support, quote requests, batch documentation, and product information. Offices in Union City, California and Shanghai, China.",
  keywords: [
    "contact peptide supplier",
    "request peptide quote",
    "Atlas BioLabs sales",
    "peptide documentation support",
    "peptide sourcing contact",
  ],
});

export default function ContactPage() {
  const breadcrumbItems = getStaticBreadcrumbItems("contact");
  const breadcrumbSchema = getBreadcrumbSchema(breadcrumbItems);

  return (
    <>
      <JsonLd id="contact-breadcrumb-schema" data={breadcrumbSchema} />

      <section className="section-space border-b border-border/70 bg-gradient-to-b from-[#f8fbff] to-white">
        <div className="site-container">
          <Breadcrumbs items={breadcrumbItems} />
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[var(--brand-blue)]">
            Contact
          </p>
          <h1 className="mt-3 max-w-4xl text-4xl font-semibold text-[var(--brand-navy)]">
            Contact Atlas BioLabs
          </h1>
          <p className="mt-4 max-w-3xl text-base leading-relaxed text-muted-foreground">
            For quote requests, product documentation, MOQ support, batch information, or commercial sourcing inquiries, contact Atlas BioLabs using the information below.
          </p>
        </div>
      </section>

      <section className="section-space">
        <div className="site-container grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <article className="surface-card space-y-6 p-6 sm:p-7">
            <div>
              <h2 className="text-xl font-semibold text-[var(--brand-navy)]">
                Contact Information
              </h2>
            </div>
            
            <div className="space-y-2">
              <p className="text-sm font-medium text-[var(--brand-navy)]">Phone</p>
              <p className="text-sm text-muted-foreground">{COMPANY_INFO.phoneDisplay}</p>
            </div>

            <div className="space-y-2 border-t border-border/30 pt-4">
              <p className="text-sm font-medium text-[var(--brand-navy)]">{COMPANY_INFO.usOffice.label}</p>
              <p className="text-sm text-muted-foreground leading-relaxed">{COMPANY_INFO.usOffice.formatted}</p>
            </div>

            <div className="space-y-2 border-t border-border/30 pt-4">
              <p className="text-sm font-medium text-[var(--brand-navy)]">{COMPANY_INFO.chinaOffice.label}</p>
              <p className="text-sm text-muted-foreground leading-relaxed">{COMPANY_INFO.chinaOffice.formatted}</p>
            </div>

            <div className="space-y-2 border-t border-border/30 pt-4">
              <p className="text-sm font-medium text-[var(--brand-navy)]">Email</p>
              <p className="text-sm text-muted-foreground">{contactDetails.recipientEmail}</p>
            </div>

            <p className="rounded-md border border-blue-200 bg-blue-50 px-3 py-2 text-xs text-blue-800">
              {contactDetails.detailsNotice}
            </p>
          </article>

          <ContactForm />
        </div>
      </section>

      <section className="section-space pt-0">
        <div className="site-container grid gap-5 md:grid-cols-3">
          {[
            {
              title: "Who should contact Atlas BioLabs",
              description:
                "This route is intended for qualified B2B buyers, procurement teams, formulation groups, and research-facing commercial accounts preparing a real sourcing discussion.",
            },
            {
              title: "What to include in your message",
              description:
                "Mention product targets, expected quantity, destination market, timeline, and any documentation or batch-transparency questions that should be addressed during quote review.",
            },
            {
              title: "What we do not provide here",
              description:
                "Atlas BioLabs contact workflows are for sourcing and documentation support, not for medical, dosing, diagnostic, veterinary, or human-use guidance.",
            },
          ].map((item) => (
            <article key={item.title} className="surface-card h-full p-6">
              <h2 className="text-xl font-semibold text-[var(--brand-navy)]">
                {item.title}
              </h2>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                {item.description}
              </p>
            </article>
          ))}
        </div>
      </section>

      <ResourceLinksPanel
        eyebrow="Need More Context?"
        title="Review the Pages Buyers Usually Open Before Contacting Us"
        description="These links help commercial buyers review products, wholesale planning, and documentation support before or after they submit a contact request."
        links={[
          {
            title: "Shop Peptides",
            href: "/shop",
            description:
              "Compare individual products, MOQ, pack sizes, and sourcing context across the catalog.",
            eyebrow: "Catalog",
          },
          {
            title: "Wholesale Supply",
            href: "/wholesale",
            description:
              "Learn how we support recurring supply, planning windows, and bulk peptide programs.",
            eyebrow: "Supply",
          },
          {
            title: "Browse Categories",
            href: "/categories",
            description:
              "Review peptide classes before narrowing down the specific products you want to discuss.",
            eyebrow: "Categories",
          },
          {
            title: "Peptide Supply Blog",
            href: "/blog",
            description:
              "Read sourcing, pricing, and documentation guides before or after you submit your contact request.",
            eyebrow: "Blog",
          },
          {
            title: "Quality Assurance",
            href: "/quality-assurance",
            description:
              "Understand our documentation review system, batch transparency support, and release workflow.",
            eyebrow: "Documentation",
          },
        ]}
      />

      <CtaSection content={contactCta} className="pt-0" />
    </>
  );
}
