import type { MetadataRoute } from "next";

import { blogCategories } from "@/lib/blog-categories";
import { getAllBlogPosts, getBlogPostModifiedDate } from "@/lib/blog";
import { absoluteUrl } from "@/lib/site-config";
import {
  blogStartHerePage,
  comparisonPages,
  downloadGuides,
  glossaryEntries,
  topLevelSeoPages,
} from "@/lib/seo-resource-data";
import { productCategories, products } from "@/lib/site-content";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();

  const staticPages: MetadataRoute.Sitemap = [
    {
      url: absoluteUrl("/"),
      lastModified: now,
      changeFrequency: "weekly",
      priority: 1,
    },
    {
      url: absoluteUrl("/shop"),
      lastModified: now,
      changeFrequency: "daily",
      priority: 0.95,
    },
    {
      url: absoluteUrl("/categories"),
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.85,
    },
    {
      url: absoluteUrl("/blog"),
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.85,
    },
    {
      url: absoluteUrl("/wholesale"),
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.8,
    },
    {
      url: absoluteUrl("/custom-requests"),
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.78,
    },
    {
      url: absoluteUrl("/about"),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.65,
    },
    {
      url: absoluteUrl("/contact"),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.65,
    },
    {
      url: absoluteUrl("/request-quote"),
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.75,
    },
    {
      url: absoluteUrl("/quality-assurance"),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.55,
    },
    {
      url: absoluteUrl("/research"),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.55,
    },
    {
      url: absoluteUrl("/compare"),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.66,
    },
    {
      url: absoluteUrl("/glossary"),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.66,
    },
    {
      url: absoluteUrl("/downloads"),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.6,
    },
    {
      url: absoluteUrl(blogStartHerePage.path),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.72,
    },
  ];

  const productPages: MetadataRoute.Sitemap = products.map((product) => ({
    url: absoluteUrl(`/shop/${product.slug}`),
    lastModified: now,
    changeFrequency: "weekly",
    priority: 0.9,
    images: [absoluteUrl(product.image)],
  }));

  const categoryPages: MetadataRoute.Sitemap = productCategories.map((category) => ({
    url: absoluteUrl(`/categories/${category.id}`),
    lastModified: now,
    changeFrequency: "weekly",
    priority: 0.82,
  }));

  const blogPages: MetadataRoute.Sitemap = getAllBlogPosts().map((post) => ({
    url: absoluteUrl(`/blog/${post.slug}`),
    lastModified: new Date(getBlogPostModifiedDate(post)),
    changeFrequency: "monthly",
    priority: 0.72,
    images: [absoluteUrl(post.image)],
  }));

  const blogCategoryPages: MetadataRoute.Sitemap = blogCategories.map((category) => ({
    url: absoluteUrl(`/blog/category/${category.slug}`),
    lastModified: now,
    changeFrequency: "monthly",
    priority: 0.68,
  }));

  const landingPages: MetadataRoute.Sitemap = Object.values(topLevelSeoPages).map(
    (page) => ({
      url: absoluteUrl(page.path),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.7,
    })
  );

  const comparisonEntries: MetadataRoute.Sitemap = Object.values(comparisonPages).map(
    (page) => ({
      url: absoluteUrl(page.path),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.64,
    })
  );

  const glossaryPages: MetadataRoute.Sitemap = Object.values(glossaryEntries).map(
    (entry) => ({
      url: absoluteUrl(`/glossary/${entry.slug}`),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.58,
    })
  );

  const downloadPages: MetadataRoute.Sitemap = Object.values(downloadGuides).map(
    (guide) => ({
      url: absoluteUrl(`/downloads/${guide.slug}`),
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.55,
    })
  );

  return [
    ...staticPages,
    ...landingPages,
    ...comparisonEntries,
    ...glossaryPages,
    ...downloadPages,
    ...categoryPages,
    ...productPages,
    ...blogPages,
    ...blogCategoryPages,
  ];
}
